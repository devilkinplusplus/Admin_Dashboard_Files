﻿using System;
using System.Collections.Generic;

namespace StudentWeb.Models
{
    public partial class ClassTable
    {
        public int Id { get; set; }
        public string ClassName { get; set; } = null!;

        public virtual StudentClass IdNavigation { get; set; } = null!;
    }
}
