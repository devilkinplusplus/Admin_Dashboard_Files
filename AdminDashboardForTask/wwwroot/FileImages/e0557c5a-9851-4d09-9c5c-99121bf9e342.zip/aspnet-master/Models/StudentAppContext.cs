﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace StudentWeb.Models
{
    public partial class StudentAppContext : DbContext
    {
        public StudentAppContext()
        {
        }

        public StudentAppContext(DbContextOptions<StudentAppContext> options)
            : base(options)
        {
        }

        public virtual DbSet<ClassTable> ClassTables { get; set; } = null!;
        public virtual DbSet<StudentClass> StudentClasses { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Server=(localdb)\\local;Database=StudentApp;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ClassTable>(entity =>
            {
                entity.ToTable("ClassTable");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.ClassName).HasMaxLength(60);

                entity.HasOne(d => d.IdNavigation)
                    .WithOne(p => p.ClassTable)
                    .HasForeignKey<ClassTable>(d => d.Id)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ClassTable_StudentClass");
            });

            modelBuilder.Entity<StudentClass>(entity =>
            {
                entity.HasKey(e => e.ClassId)
                    .HasName("PK_StudentClass_1");

                entity.ToTable("StudentClass");

                entity.Property(e => e.Name).HasMaxLength(60);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
