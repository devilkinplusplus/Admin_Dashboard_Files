﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;
namespace StudentWeb.Models
{
    public class GetClass : PageModel
    {
        public string ClassName { get; set; }
        public string Id { get; set; }
        public GetClass onGet()
        {
            string connectionString = @"Server=(localdb)\\local;Database=StudentApp;Trusted_Connection=True;MultipleActiveResultSets=true";
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            string SqlString = "SELECT * FROM ClassTable";
            SqlCommand sqlCommand = new SqlCommand(SqlString, con);
            SqlDataReader reader = sqlCommand.ExecuteReader();
            GetClass getClass = new GetClass();
            if (reader.Read())
            {
                getClass.ClassName = reader["ClassName"].ToString();
                getClass.Id = reader["Id"].ToString();
            }
            con.Close();
            return getClass;
        }
    }
}