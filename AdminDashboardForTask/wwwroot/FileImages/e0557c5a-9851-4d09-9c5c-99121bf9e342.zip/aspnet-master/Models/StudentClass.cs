﻿using System;
using System.Collections.Generic;

namespace StudentWeb.Models
{
    public partial class StudentClass
    {
        public int Id { get; set; }
        public string Name { get; set; } = null!;
        public int ClassId { get; set; }

        public virtual ClassTable ClassTable { get; set; } = null!;
    }
}
