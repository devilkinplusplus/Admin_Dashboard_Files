﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using StudentWeb.Models;
using System.Data;
using System.Diagnostics;

namespace StudentWeb.Controllers
{
    public class HomeController : Controller
    {
        string connectionAdress = @"Server = (localdb)\local; Database = StudentApp; Trusted_Connection = true";

        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult ManageClass()
        {
            return View();
        }

        [HttpPost()]
        public ActionResult AddClassDB(ClassTable _table)
        {
            string ClassName;
            ClassName = _table.ClassName;
            SqlConnection connection = new SqlConnection(connectionAdress);
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            command.CommandText = "INSERT INTO ClassTable (ClassName) VALUES ('" + ClassName + "')";
            connection.Open();
            command.ExecuteNonQuery();
            connection.Close();
            return View("ManageClass");
        }
        [HttpGet()]
        public IActionResult GetClassInfo()
        {
            return View();
        }
        public IActionResult ViewPage()
        {
            return View();
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}